<?php
/**
 * Mandatory public API of marvel module
 *
 * @package    mod_marvel
 * @copyright  2021 tresipunt
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Given an object containing all the necessary data,
 * (defined by the form in mod_form.php) this function
 * will create a new instance and return the id number
 * of the new instance.
 *
 * @global object
 * @param object $marvel
 * @return bool|int
 */
function marvel_add_instance($marvel) {
    global $DB;

    $data = new stdClass();
    $data->course = (int) $marvel->course;
    $data->name = $marvel->name;
    $data->typelist = $marvel->typelist;
    $data->timecreated = time();
    $data->timemodified = time();

    return $DB->insert_record("marvel", $data);
}
/**
 * Given an object containing all the necessary data,
 * (defined by the form in mod_form.php) this function
 * will update an existing instance with new data.
 *
 * @global object
 * @param object $marvel
 * @return bool
 */
function marvel_update_instance($marvel) {
    global $DB;

    $data = new stdClass();
    $data->course = (int) $marvel->course;
    $data->name = $marvel->name;
    $data->typelist = $marvel->typelist;
    $data->timemodified = time();
    $data->id = $marvel->instance;

    return $DB->update_record("marvel", $data);
}
/**
 * Given an ID of an instance of this module,
 * this function will permanently delete the instance
 * and any data that depends on it.
 *
 * @global object
 * @param int $id
 * @return bool
 */
function marvel_delete_instance($id) {
    global $DB;

    if (! $marvel = $DB->get_record("marvel", array("id"=>$id))) {
        return false;
    }

    $result = true;

    if (! $DB->delete_records("marvel", array("id"=>$marvel->id))) {
        $result = false;
    }

    return $result;
}
/**
 * @uses FEATURE_IDNUMBER
 * @uses FEATURE_GROUPS
 * @uses FEATURE_GROUPINGS
 * @uses FEATURE_MOD_INTRO
 * @uses FEATURE_COMPLETION_TRACKS_VIEWS
 * @uses FEATURE_GRADE_HAS_GRADE
 * @uses FEATURE_GRADE_OUTCOMES
 * @param string $feature FEATURE_xx constant for requested feature
 * @return bool|null True if module supports feature, false if not, null if doesn't know
 */
function marvel_supports($feature) {
    switch($feature) {
        case FEATURE_IDNUMBER:                return false;
        case FEATURE_GROUPS:                  return false;
        case FEATURE_GROUPINGS:               return false;
        case FEATURE_MOD_INTRO:               return false;
        case FEATURE_COMPLETION_TRACKS_VIEWS: return false;
        case FEATURE_GRADE_HAS_GRADE:         return false;
        case FEATURE_GRADE_OUTCOMES:          return false;
        case FEATURE_NO_VIEW_LINK:            return false;
        case FEATURE_MOD_ARCHETYPE:           return MOD_ARCHETYPE_RESOURCE;
        case FEATURE_BACKUP_MOODLE2:          return true;
        default: return null;
    }
}