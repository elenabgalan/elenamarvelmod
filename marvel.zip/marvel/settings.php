<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Resource module admin settings and defaults
 *
 * @package    mod_marvel
 * @copyright  2021 tresipunt
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

if ($ADMIN->fulltree) {

    // Marvel API url.
    $settings->add(new admin_setting_configtext('mod_marvel/url',
        get_string('url', 'mod_marvel'), get_string('url_desc', 'mod_marvel'), 'http://gateway.marvel.com/v1/public/', PARAM_RAW, 100));

    // Marvel API public key.
    $settings->add(new admin_setting_configtext('mod_marvel/publickey',
        get_string('publickey', 'mod_marvel'), get_string('publickey_desc', 'mod_marvel'), '', PARAM_RAW, 100));

    // Marvel API private key.
    $settings->add(new admin_setting_configtext('mod_marvel/privatekey',
        get_string('privatekey', 'mod_marvel'), get_string('privatekey_desc', 'mod_marvel'), '', PARAM_RAW, 100));
}
