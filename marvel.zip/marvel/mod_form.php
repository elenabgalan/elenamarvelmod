<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Add marvel form
 *
 * @package    mod_marvel
 * @copyright  2021 tresipunt
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

require_once ($CFG->dirroot.'/course/moodleform_mod.php');

if (!defined('MOODLE_INTERNAL')) {
    die('Direct access to this script is forbidden.');    ///  It must be included from a Moodle page
}

require_once($CFG->dirroot.'/course/moodleform_mod.php');
require_once($CFG->dirroot.'/mod/marvel/lib.php');

class mod_marvel_mod_form extends moodleform_mod {

    function definition() {

        $mform =& $this->_form;

        // Name field
        $mform->addElement('text', 'name', get_string('name', 'marvel'), array('size' => '64'));
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', get_string('maximumchars', '', 255), 'maxlength', 255, 'server');
        $mform->addRule('name', null, 'required', null, 'server');

        //Typelist field
        $radio = array();
        $radio[] = $mform->createElement('radio', 'typelist', null, get_string('character', 'marvel'), 'character');
        $radio[] = $mform->createElement('radio', 'typelist', null, get_string('comics', 'marvel'), 'comics');
        $radio[] = $mform->createElement('radio', 'typelist', null, get_string('creators', 'marvel'), 'creators');
        $radio[] = $mform->createElement('radio', 'typelist', null, get_string('events', 'marvel'), 'events');
        $radio[] = $mform->createElement('radio', 'typelist', null, get_string('series', 'marvel'), 'series');
        $radio[] = $mform->createElement('radio', 'typelist', null, get_string('stories', 'marvel'), 'stories');
        $mform->addGroup($radio, 'typelist', get_string('typelist', 'marvel'), ' ', false);
        $mform->addHelpButton('typelist', 'typelist', 'marvel');
        $mform->setDefault('typelist', 'character');

        $this->standard_coursemodule_elements();

        $this->add_action_buttons();
    }
}