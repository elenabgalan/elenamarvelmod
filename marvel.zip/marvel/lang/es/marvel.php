<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'marvel', language 'en'
 *
 * @package    mod_marvel
 * @copyright  2021 tresipunt
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
$string['pluginname'] = 'Marvel';
$string['modulename'] = 'Marvel';
$string['modulename_help'] = 'modulename_help';
$string['modulenameplural'] = 'Marvel plural';
$string['modulenamepluralformatted'] = 'Marvel plural formated';
$string['pluginadministration'] = 'Marvel administration';
$string['pagetitle'] = 'Recurso marvel';
$string['emptyconfigsettings'] = 'Debe configurar los elementos url, publickey y privatekey';

$string['character'] = 'Personajes';
$string['comics'] = 'Comics';
$string['creators'] = 'Creadores';
$string['events'] = 'Eventos';
$string['series'] = 'Series';
$string['stories'] = 'Historias';
$string['name'] = 'Nombre';
$string['name_help'] = 'Nombre de la recurso';
$string['typelist'] = 'Listado en el que se muestra información sobre el mundo de Marvel';
$string['publickey_desc'] = 'Clave pública para usar en las llamadas de los servicios web de Marvel';
$string['publickey'] = 'Clave pública';
$string['privatekey_desc'] = 'Clave privada para usar en las llamadas de los servicios web de Marvel';
$string['privatekey'] = 'Clave privada';
$string['nothingtoshow'] = 'Ha ocurrido un error, no se puede mostrar el contenido deseado.';
$string['characterstitle'] = 'Listado de personajes';
$string['comicstitle'] = 'Listado de comics';
$string['creatorstitle'] = 'Listado de creadores';
$string['eventstitle'] = 'Listado de eventos';
$string['seriestitle'] = 'Listado de series';
$string['storiestitle'] = 'Listado de historias';
