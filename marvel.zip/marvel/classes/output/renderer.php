<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * This file contains the renderers for the marvel within Moodle
 *
 * @copyright 2021 tresipunt
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @package mod_marvel
 */

if (!defined('MOODLE_INTERNAL')) {
    die('Direct access to this script is forbidden.');    ///  It must be included from a Moodle page
}
require_once $CFG->dirroot . '/mod/marvel/classes/output/character_page.php';
/**
 * The primary renderer for the marvel.
 */
class mod_marvel_renderer extends plugin_renderer_base {

    /**
     * Render marvel characters list.
     * @param $page
     * @return bool|string
     * @throws coding_exception
     * @throws moodle_exception
     */
    public function render_characters($page) {

        list($characters, $attribution) = \mod_marvel\marvel_calls::mod_marvel_get_characters();
        $data = [
            'list' => $characters,
            'attribution' => $attribution,
            'title' => get_string('characterstitle', 'mod_marvel')];
        if (empty($characters)) {
            global $OUTPUT;
            return $OUTPUT->container(get_string('nothingtoshow', 'marvel'), 'alert alert-warning');
        }

        return parent::render_from_template('mod_marvel/content', $data);
    }

    /**
     * Render marvel comics list.
     * @param $page
     * @return bool|string
     * @throws coding_exception
     * @throws moodle_exception
     */
    public function render_comics($page) {

        list($comics, $attribution) = \mod_marvel\marvel_calls::mod_marvel_get_comics();
        $data = [
            'list' => $comics,
            'attribution' => $attribution,
            'title' => get_string('comicstitle', 'mod_marvel')];
        if (empty($comics)) {
            global $OUTPUT;
            return $OUTPUT->container(get_string('nothingtoshow', 'marvel'), 'alert alert-warning');
        }

        return parent::render_from_template('mod_marvel/content', $data);
    }

    /**
     * Render marvel creators list.
     * @param $page
     * @return bool|string
     * @throws coding_exception
     * @throws moodle_exception
     */
    public function render_creators($page) {

        list($creators, $attribution) = \mod_marvel\marvel_calls::mod_marvel_get_creators();
        $data = [
            'list' => $creators,
            'attribution' => $attribution,
            'title' => get_string('creatorstitle', 'mod_marvel')];
        if (empty($creators)) {
            global $OUTPUT;
            return $OUTPUT->container(get_string('nothingtoshow', 'marvel'), 'alert alert-warning');
        }

        return parent::render_from_template('mod_marvel/content', $data);
    }
    /**
     * Render marvel events list.
     * @param $page
     * @return bool|string
     * @throws coding_exception
     * @throws moodle_exception
     */
    public function render_events($page) {

        list($results, $attribution) = \mod_marvel\marvel_calls::mod_marvel_get_events();
        $data = [
            'list' => $results,
            'attribution' => $attribution,
            'title' => get_string('eventstitle', 'mod_marvel')];
        if (empty($results)) {
            global $OUTPUT;
            return $OUTPUT->container(get_string('nothingtoshow', 'marvel'), 'alert alert-warning');
        }

        return parent::render_from_template('mod_marvel/content', $data);
    }
    /**
     * Render marvel series list.
     * @param $page
     * @return bool|string
     * @throws coding_exception
     * @throws moodle_exception
     */
    public function render_series($page) {

        list($results, $attribution) = \mod_marvel\marvel_calls::mod_marvel_get_series();
        $data = [
            'list' => $results,
            'attribution' => $attribution,
            'title' => get_string('seriestitle', 'mod_marvel')];
        if (empty($results)) {
            global $OUTPUT;
            return $OUTPUT->container(get_string('nothingtoshow', 'marvel'), 'alert alert-warning');
        }

        return parent::render_from_template('mod_marvel/content', $data);
    }
    /**
     * Render marvel stories list.
     * @param $page
     * @return bool|string
     * @throws coding_exception
     * @throws moodle_exception
     */
    public function render_stories($page) {

        list($results, $attribution) = \mod_marvel\marvel_calls::mod_marvel_get_stories();
        $data = [
            'list' => $results,
            'attribution' => $attribution,
            'title' => get_string('storiestitle', 'mod_marvel')];
        if (empty($results)) {
            global $OUTPUT;
            return $OUTPUT->container(get_string('nothingtoshow', 'marvel'), 'alert alert-warning');
        }

        return parent::render_from_template('mod_marvel/content', $data);
    }
}