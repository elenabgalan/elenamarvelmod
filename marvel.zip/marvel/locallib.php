<?php
/**
 * @return bool
 * @throws dml_exception
 */
function mod_marvel_is_config_empty() {
    if (empty(get_config('mod_marvel', 'publickey'))
        || empty(get_config('mod_marvel', 'privatekey'))
        ||empty(get_config('mod_marvel', 'url'))) {
        return true;
    }
    return false;
}