<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Marvel module
 *
 * @package mod_marvel
 * @copyright  2021 tresipunt
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require('../../config.php');
require_once($CFG->dirroot.'/course/lib.php');
require_once($CFG->dirroot.'/mod/marvel/classes/output/renderer.php');
require_once($CFG->dirroot.'/mod/marvel/locallib.php');

require_once($CFG->libdir.'/completionlib.php');
use mod_marvel\output\character_page;

$id      = optional_param('id', 0, PARAM_INT); // Course Module ID
$p       = optional_param('p', 0, PARAM_INT);  // Marvel instance ID

// Find resource
if ($p) {
    if (!$marvel = $DB->get_record('marvel', array('id'=>$p))) {
        print_error('invalidaccessparameter');
    }
    $cm = get_coursemodule_from_instance('marvel', $marvel->id, $marvel->course, false, MUST_EXIST);

} else {
    if (!$cm = get_coursemodule_from_id('marvel', $id)) {
        print_error('invalidcoursemodule');
    }
    $marvel = $DB->get_record('marvel', array('id'=>$cm->instance), '*', MUST_EXIST);
}

$course = $DB->get_record('course', array('id'=>$cm->course), '*', MUST_EXIST);

// Require login and capabitily
require_course_login($course, true, $cm);
$context = context_module::instance($cm->id);
require_capability('mod/marvel:view', $context);

// Define page.
$PAGE->set_context($context);
$url = new moodle_url('/mod/marvel/view.php', ['id'=> $cm->id]);
$PAGE->set_url($url);
$PAGE->set_title($marvel->name);
$PAGE->set_heading(get_string('pagetitle', 'mod_marvel'));

$renderer = $PAGE->get_renderer('mod_marvel');
$page = new character_page();

echo $renderer->header();

// Required settings filled: url, public and private keys.
if (mod_marvel_is_config_empty()) {
    echo $OUTPUT->container(get_string('emptyconfigsettings', 'marvel'), 'alert alert-warning');
} else {
    switch ($marvel->typelist) {
        case 'character': echo $renderer->render_characters($page);break;
        case 'comics': echo $renderer->render_comics($page);break;
        case 'creators': echo $renderer->render_creators($page);break;
        case 'events': echo $renderer->render_events($page);break;
        case 'series': echo $renderer->render_series($page);break;
        case 'stories': echo $renderer->render_stories($page);break;
        default: echo $OUTPUT->container(get_string('nothingtoshow', 'marvel'), 'alert alert-warning');
    }
}

echo $renderer->footer();