<?php
global $CFG;
require_once $CFG->dirroot . '\mod\marvel\locallib.php';
class marvel_calls_testcase extends advanced_testcase {

    private $emptyvar = '';
    private $anyvar = 'AAA';
    private $url = 'http://gateway.marvel.com/v1/public/';
    private $publickey = '809fa665718b6a0b765e9c4589701d56';
    private $privatekey = '6b7f36fc4cd4dccd47f15a70bff5915aa54a1bb3';

    /**
     * Method to test mod_marvel_get_characters function
     */
    public function test_mod_marvel_get_characters() {
        fwrite(STDOUT, " -------------------------------------------  " . "\n");
        fwrite(STDOUT, " -- Test mod_marvel_get_characters()  " . "\n");

        $this->resetAfterTest(true);
        // Prueba 1: que los elementos de configuración esten vacios, [] array vacio
        set_config('url', $this->emptyvar, 'mod_marvel');
        set_config('publickey', $this->emptyvar, 'mod_marvel');
        set_config('privatekey', $this->emptyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 1  " . "\n");
        $test1 = \mod_marvel\marvel_calls::mod_marvel_get_characters();
        $this->assertIsArray($test1);
        $this->assertIsArray($test1[0]);
        $this->assertEmpty($test1[0]);
        $this->assertIsString($test1[1]);
        $this->assertEmpty($test1[1]);

        // Prueba 2: que 1 de los elementos de configuración esté vacios, [] array vacio
        set_config('publickey', $this->anyvar, 'mod_marvel');
        set_config('privatekey', $this->anyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 2  " . "\n");
        $test2 = \mod_marvel\marvel_calls::mod_marvel_get_characters();
        $this->assertIsArray($test2);
        $this->assertIsArray($test2[0]);
        $this->assertEmpty($test2[0]);
        $this->assertIsString($test2[1]);
        $this->assertEmpty($test2[1]);

        // Prueba 3: que los elementos de configuración estén rellenos pero los valores sean erroneos, [] array vacio
        set_config('url', $this->anyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 3  " . "\n");
        $test3 = \mod_marvel\marvel_calls::mod_marvel_get_characters();
        $this->assertIsArray($test3);
        $this->assertIsArray($test3[0]);
        $this->assertEmpty($test3[0]);
        $this->assertIsString($test3[1]);
        $this->assertEmpty($test3[1]);

        // Prueba 4: que los elementos de configuración estén rellenos, [] array relleno
        set_config('url', $this->url , 'mod_marvel');
        set_config('publickey', $this->publickey , 'mod_marvel');
        set_config('privatekey', $this->privatekey, 'mod_marvel');
        fwrite(STDOUT, " Prueba 4  " . "\n");
        $test4 = \mod_marvel\marvel_calls::mod_marvel_get_characters();
        $this->assertIsArray($test4);
        $this->assertIsArray($test4[0]);
        $this->assertNotEmpty($test4[0]);
        $this->assertIsString($test4[1]);
        $this->assertNotEmpty($test4[1]);
        $data = $test4[0][0];
        $this->assertArrayHasKey('name', $data);
        $this->assertArrayHasKey('imgsrc', $data);


        fwrite(STDOUT, " -- END --- Test mod_marvel_get_characters()  " . "\n");
    }

    /**
     * Method to test mod_marvel_get_comics function
     */
    public function test_mod_marvel_get_comics() {
        fwrite(STDOUT, " -------------------------------------------  " . "\n");
        fwrite(STDOUT, " -- Test mod_marvel_get_comics()  " . "\n");

        $this->resetAfterTest(true);
        // Prueba 1: que los elementos de configuración esten vacios, [] array vacio
        set_config('url', $this->emptyvar, 'mod_marvel');
        set_config('publickey', $this->emptyvar, 'mod_marvel');
        set_config('privatekey', $this->emptyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 1  " . "\n");
        $test1 = \mod_marvel\marvel_calls::mod_marvel_get_comics();
        $this->assertIsArray($test1);
        $this->assertIsArray($test1[0]);
        $this->assertEmpty($test1[0]);
        $this->assertIsString($test1[1]);
        $this->assertEmpty($test1[1]);

        // Prueba 2: que 1 de los elementos de configuración esté vacios, [] array vacio
        set_config('publickey', $this->anyvar, 'mod_marvel');
        set_config('privatekey', $this->anyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 2  " . "\n");
        $test2 = \mod_marvel\marvel_calls::mod_marvel_get_comics();
        $this->assertIsArray($test2);
        $this->assertIsArray($test2[0]);
        $this->assertEmpty($test2[0]);
        $this->assertIsString($test2[1]);
        $this->assertEmpty($test2[1]);

        // Prueba 3: que los elementos de configuración estén rellenos pero los valores sean erroneos, [] array vacio
        set_config('url', $this->anyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 3  " . "\n");
        $test3 = \mod_marvel\marvel_calls::mod_marvel_get_comics();
        $this->assertIsArray($test3);
        $this->assertIsArray($test3[0]);
        $this->assertEmpty($test3[0]);
        $this->assertIsString($test3[1]);
        $this->assertEmpty($test3[1]);

        // Prueba 4: que los elementos de configuración estén rellenos, [] array relleno
        set_config('url', $this->url, 'mod_marvel');
        set_config('publickey', $this->publickey, 'mod_marvel');
        set_config('privatekey', $this->privatekey, 'mod_marvel');
        fwrite(STDOUT, " Prueba 4  " . "\n");
        $test4 = \mod_marvel\marvel_calls::mod_marvel_get_comics();
        $this->assertIsArray($test4);
        $this->assertIsArray($test4[0]);
        $this->assertNotEmpty($test4[0]);
        $this->assertIsString($test4[1]);
        $this->assertNotEmpty($test4[1]);
        $data = $test4[0][0];
        $this->assertArrayHasKey('name', $data);
        $this->assertArrayHasKey('imgsrc', $data);

        fwrite(STDOUT, " -- END --- Test mod_marvel_get_comics()  " . "\n");
    }

    /**
     * Method to test mod_marvel_get_creators function
     */
    public function test_mod_marvel_get_creators() {
        fwrite(STDOUT, " -------------------------------------------  " . "\n");
        fwrite(STDOUT, " -- Test mod_marvel_get_creators()  " . "\n");

        $this->resetAfterTest(true);
        // Prueba 1: que los elementos de configuración esten vacios, [] array vacio
        set_config('url', $this->emptyvar, 'mod_marvel');
        set_config('publickey', $this->emptyvar, 'mod_marvel');
        set_config('privatekey', $this->emptyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 1  " . "\n");
        $test1 = \mod_marvel\marvel_calls::mod_marvel_get_creators();
        $this->assertIsArray($test1);
        $this->assertIsArray($test1[0]);
        $this->assertEmpty($test1[0]);
        $this->assertIsString($test1[1]);
        $this->assertEmpty($test1[1]);

        // Prueba 2: que 1 de los elementos de configuración esté vacios, [] array vacio
        set_config('publickey', $this->anyvar, 'mod_marvel');
        set_config('privatekey', $this->anyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 2  " . "\n");
        $test2 = \mod_marvel\marvel_calls::mod_marvel_get_creators();
        $this->assertIsArray($test2);
        $this->assertIsArray($test2[0]);
        $this->assertEmpty($test2[0]);
        $this->assertIsString($test2[1]);
        $this->assertEmpty($test2[1]);

        // Prueba 3: que los elementos de configuración estén rellenos pero los valores sean erroneos, [] array vacio
        set_config('url', $this->anyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 3  " . "\n");
        $test3 = \mod_marvel\marvel_calls::mod_marvel_get_creators();
        $this->assertIsArray($test3);
        $this->assertIsArray($test3[0]);
        $this->assertEmpty($test3[0]);
        $this->assertIsString($test3[1]);
        $this->assertEmpty($test3[1]);

        // Prueba 4: que los elementos de configuración estén rellenos, [] array relleno
        set_config('url', $this->url, 'mod_marvel');
        set_config('publickey', $this->publickey, 'mod_marvel');
        set_config('privatekey', $this->privatekey, 'mod_marvel');
        fwrite(STDOUT, " Prueba 4  " . "\n");
        $test4 = \mod_marvel\marvel_calls::mod_marvel_get_creators();
        $this->assertIsArray($test4);
        $this->assertIsArray($test4[0]);
        $this->assertNotEmpty($test4[0]);
        $this->assertIsString($test4[1]);
        $this->assertNotEmpty($test4[1]);
        $data = $test4[0][0];
        $this->assertArrayHasKey('name', $data);
        $this->assertArrayHasKey('imgsrc', $data);
        fwrite(STDOUT, " -- END --- Test mod_marvel_get_creators()  " . "\n");
    }

    /**
     * Method to test mod_marvel_get_events function
     */
    public function test_mod_marvel_get_events() {
        fwrite(STDOUT, " -------------------------------------------  " . "\n");
        fwrite(STDOUT, " -- Test mod_marvel_get_events()  " . "\n");

        $this->resetAfterTest(true);
        // Prueba 1: que los elementos de configuración esten vacios, [] array vacio
        set_config('url', $this->emptyvar, 'mod_marvel');
        set_config('publickey', $this->emptyvar, 'mod_marvel');
        set_config('privatekey', $this->emptyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 1  " . "\n");
        $test1 = \mod_marvel\marvel_calls::mod_marvel_get_events();
        $this->assertIsArray($test1);
        $this->assertIsArray($test1[0]);
        $this->assertEmpty($test1[0]);
        $this->assertIsString($test1[1]);
        $this->assertEmpty($test1[1]);

        // Prueba 2: que 1 de los elementos de configuración esté vacios, [] array vacio
        set_config('publickey', $this->anyvar, 'mod_marvel');
        set_config('privatekey', $this->anyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 2  " . "\n");
        $test2 = \mod_marvel\marvel_calls::mod_marvel_get_events();
        $this->assertIsArray($test2);
        $this->assertIsArray($test2[0]);
        $this->assertEmpty($test2[0]);
        $this->assertIsString($test2[1]);
        $this->assertEmpty($test2[1]);

        // Prueba 3: que los elementos de configuración estén rellenos pero los valores sean erroneos, [] array vacio
        set_config('url', $this->anyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 3  " . "\n");
        $test3 = \mod_marvel\marvel_calls::mod_marvel_get_events();
        $this->assertIsArray($test3);
        $this->assertIsArray($test3[0]);
        $this->assertEmpty($test3[0]);
        $this->assertIsString($test3[1]);
        $this->assertEmpty($test3[1]);

        // Prueba 4: que los elementos de configuración estén rellenos, [] array relleno
        set_config('url', $this->url, 'mod_marvel');
        set_config('publickey', $this->publickey, 'mod_marvel');
        set_config('privatekey', $this->privatekey, 'mod_marvel');
        fwrite(STDOUT, " Prueba 4  " . "\n");
        $test4 = \mod_marvel\marvel_calls::mod_marvel_get_events();
        $this->assertIsArray($test4);
        $this->assertIsArray($test4[0]);
        $this->assertNotEmpty($test4[0]);
        $this->assertIsString($test4[1]);
        $this->assertNotEmpty($test4[1]);
        $data = $test4[0][0];
        $this->assertArrayHasKey('name', $data);
        $this->assertArrayHasKey('imgsrc', $data);
        $this->assertArrayHasKey('description', $data);
        fwrite(STDOUT, " -- END --- Test mod_marvel_get_events()  " . "\n");
    }

    /**
     * Method to test mod_marvel_get_series function
     */
    public function test_mod_marvel_get_series() {
        fwrite(STDOUT, " -------------------------------------------  " . "\n");
        fwrite(STDOUT, " -- Test mod_marvel_get_series()  " . "\n");

        $this->resetAfterTest(true);
        // Prueba 1: que los elementos de configuración esten vacios, [] array vacio
        set_config('url', $this->emptyvar, 'mod_marvel');
        set_config('publickey', $this->emptyvar, 'mod_marvel');
        set_config('privatekey', $this->emptyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 1  " . "\n");
        $test1 = \mod_marvel\marvel_calls::mod_marvel_get_series();
        $this->assertIsArray($test1);
        $this->assertIsArray($test1[0]);
        $this->assertEmpty($test1[0]);
        $this->assertIsString($test1[1]);
        $this->assertEmpty($test1[1]);

        // Prueba 2: que 1 de los elementos de configuración esté vacios, [] array vacio
        set_config('publickey', $this->anyvar, 'mod_marvel');
        set_config('privatekey', $this->anyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 2  " . "\n");
        $test2 = \mod_marvel\marvel_calls::mod_marvel_get_series();
        $this->assertIsArray($test2);
        $this->assertIsArray($test2[0]);
        $this->assertEmpty($test2[0]);
        $this->assertIsString($test2[1]);
        $this->assertEmpty($test2[1]);

        // Prueba 3: que los elementos de configuración estén rellenos pero los valores sean erroneos, [] array vacio
        set_config('url', $this->anyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 3  " . "\n");
        $test3 = \mod_marvel\marvel_calls::mod_marvel_get_series();
        $this->assertIsArray($test3);
        $this->assertIsArray($test3[0]);
        $this->assertEmpty($test3[0]);
        $this->assertIsString($test3[1]);
        $this->assertEmpty($test3[1]);

        // Prueba 4: que los elementos de configuración estén rellenos, [] array relleno
        set_config('url', $this->url, 'mod_marvel');
        set_config('publickey', $this->publickey, 'mod_marvel');
        set_config('privatekey', $this->privatekey, 'mod_marvel');
        fwrite(STDOUT, " Prueba 4  " . "\n");
        $test4 = \mod_marvel\marvel_calls::mod_marvel_get_series();
        $this->assertIsArray($test4);
        $this->assertIsArray($test4[0]);
        $this->assertNotEmpty($test4[0]);
        $this->assertIsString($test4[1]);
        $this->assertNotEmpty($test4[1]);
        $data = $test4[0][0];
        $this->assertArrayHasKey('name', $data);
        $this->assertArrayHasKey('imgsrc', $data);

        fwrite(STDOUT, " -- END --- Test mod_marvel_get_series()  " . "\n");
    }

    /**
     * Method to test mod_marvel_get_stories function
     */
    public function test_mod_marvel_get_stories() {
        fwrite(STDOUT, " -------------------------------------------  " . "\n");
        fwrite(STDOUT, " -- Test mod_marvel_get_stories()  " . "\n");

        $this->resetAfterTest(true);
        // Prueba 1: que los elementos de configuración esten vacios, [] array vacio
        set_config('url', $this->emptyvar, 'mod_marvel');
        set_config('publickey', $this->emptyvar, 'mod_marvel');
        set_config('privatekey', $this->emptyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 1  " . "\n");
        $test1 = \mod_marvel\marvel_calls::mod_marvel_get_stories();
        $this->assertIsArray($test1);
        $this->assertIsArray($test1[0]);
        $this->assertEmpty($test1[0]);
        $this->assertIsString($test1[1]);
        $this->assertEmpty($test1[1]);

        // Prueba 2: que 1 de los elementos de configuración esté vacios, [] array vacio
        set_config('publickey', $this->anyvar, 'mod_marvel');
        set_config('privatekey', $this->anyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 2  " . "\n");
        $test2 = \mod_marvel\marvel_calls::mod_marvel_get_stories();
        $this->assertIsArray($test2);
        $this->assertIsArray($test2[0]);
        $this->assertEmpty($test2[0]);
        $this->assertIsString($test2[1]);
        $this->assertEmpty($test2[1]);

        // Prueba 3: que los elementos de configuración estén rellenos pero los valores sean erroneos, [] array vacio
        set_config('url', $this->anyvar, 'mod_marvel');
        fwrite(STDOUT, " Prueba 3  " . "\n");
        $test3 = \mod_marvel\marvel_calls::mod_marvel_get_stories();
        $this->assertIsArray($test3);
        $this->assertIsArray($test3[0]);
        $this->assertEmpty($test3[0]);
        $this->assertIsString($test3[1]);
        $this->assertEmpty($test3[1]);

        // Prueba 4: que los elementos de configuración estén rellenos, [] array relleno
        set_config('url', $this->url, 'mod_marvel');
        set_config('publickey', $this->publickey, 'mod_marvel');
        set_config('privatekey', $this->privatekey, 'mod_marvel');
        fwrite(STDOUT, " Prueba 4  " . "\n");
        $test4 = \mod_marvel\marvel_calls::mod_marvel_get_stories();
        $this->assertIsArray($test4);
        $this->assertIsArray($test4[0]);
        $this->assertNotEmpty($test4[0]);
        $this->assertIsString($test4[1]);
        $this->assertNotEmpty($test4[1]);
        $data = $test4[0][0];
        $this->assertArrayHasKey('name', $data);

        fwrite(STDOUT, " -- END --- Test mod_marvel_get_stories()  " . "\n");
    }
}